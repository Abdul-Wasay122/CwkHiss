package refdefcwk;

public enum JobType {
    DESIGN, MAINTENANCE, INSTALLATION
}