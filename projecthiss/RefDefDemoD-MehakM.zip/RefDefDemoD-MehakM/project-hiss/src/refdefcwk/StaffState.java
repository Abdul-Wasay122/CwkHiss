package refdefcwk;

public enum StaffState {
    AVAILABLE, WORKING, ON_LEAVE
}